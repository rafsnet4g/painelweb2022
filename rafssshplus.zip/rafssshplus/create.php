<?php
require_once("pages/system/pass.php");
$user = "root";
$host = "localhost";
$dbname = "sshplus";

$sql_file = fopen('sshplus.sql', 'r');
$sql = fread($sql_file, filesize('sshplus.sql'));
$conn = new PDO("mysql:host=" . $host . ";dbname=" . $dbname , $user, $pass);
$conn->exec($sql); ?>